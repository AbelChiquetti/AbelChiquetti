<h2>Este site foi desenvolvido para a Dra. Denise Chiquetti, e foi autorizado a hospedagem dos arquivos no GitHub. Não é permitido copiar arquivos deste site (●'◡'●)</h2>
